// render.js — isometric hex-die renderer for the terminal board.
//
// The whole board is drawn into an offscreen character canvas; the caller
// decides which window of that canvas to show on screen.
//
// Shapes are *shaded*, not outlined: a floor tile is a filled diamond, a die
// is a cube whose three faces have their own brightness.  The borders between
// two shapes run diagonally, so they are drawn with quarter block characters
// (▀ ▄ ▌ ▐ ▘ ▝ ▖ ▗ ▞ ▟ ...) which gives the edges four times the resolution
// of a plain character cell.
//
// Every character cell keeps the colour of its four quarters separately, so
// two shapes that meet inside one cell can both be drawn (one as background,
// one as a quarter block in the foreground).

import { DIRS, rollState, TIMING } from './core.js';

export const HEX_W = 14, HEX_H = 11;

// Ported from dice_small.py: a 14x11 hexagon with three faces (top / left /
// right).  Pips sit on a 3x3 (u,v) grid which is projected per face.
export const HEX_PIPS = {
  1: [[0, 0]],
  2: [[-1, -1], [1, 1]],
  3: [[-1, -1], [0, 0], [1, 1]],
  4: [[-1, -1], [-1, 1], [1, -1], [1, 1]],
  5: [[-1, -1], [-1, 1], [0, 0], [1, -1], [1, 1]],
  6: [[-1, -1], [-1, 0], [-1, 1], [1, -1], [1, 0], [1, 1]],
};
// The pips are dots, not numbers; their colour tells the value.
// The centre of each face, [col, row].
export const FACE_CENTER = { top: [6, 3], left: [3, 6], right: [10, 6] };
// [col, row] of a pip for each face.
// Every pip is the same round dot, so the faces always look alike.
export const PIP_DOT = '\u25CF';   // a filled circle
export const HEX_PROJ = {
  top:   (u, v) => [6 + 2 * u - 2 * v, 3 + u + v],
  left:  (u, v) => [3 + 2 * u, 6 + u + v],
  right: (u, v) => [10 - 2 * u, 6 + u + v],
};
// Screen step of one board cell: +x goes right-down, +y goes left-down.
export const HEX_DX = 7, HEX_DY = 3;

// Height of the cube in characters: the vertical edge of the hexagon is 4
// rows.  A die rests ON the floor tile, so its hexagon is drawn this many
// rows above the tile, exactly like the canvas version does
// (CUBE_UP = CUBE_V in ~/dice2d/public/game.js).
export const HEX_CUBE_H = 4;

const SINK_DROP = HEX_CUBE_H;
const SIDE_SLOPE = 3 / 6.5;
function sinkProgressOf(die) {
  if (!die || !die.sinking) return 0;
  return Math.max(0, Math.min(1, 1 - die.sinkRemaining / TIMING.sink));
}
function sinkDropOf(die) {
  return sinkProgressOf(die) * SINK_DROP;
}
// How high a cell of a face stands above the bottom edge of that face.  The
// top face is clipped as a whole: it is drawn 4 rows above the side faces
// (that is the height of the cube), and while the die sinks the whole face
// moves down, so the faces stay next to each other and the die keeps its
// silhouette.
function faceHeight(face, r, c) {
  if (face === 'top') return HEX_CUBE_H;
  const bottom = face === 'left' ? 7 + SIDE_SLOPE * c : 7 + SIDE_SLOPE * (13 - c);
  return bottom - r;
}

// The three faces are parallelograms (row, col coordinates):
//   top   : W(3,0) N(0,6.5) S(6,6.5) E(3,13)
//   left  : W(3,0) S(6,6.5) (10,6.5) (7,0)
//   right : E(3,13) S(6,6.5) (10,6.5) (7,13)
const HEX_QUADS = {
  top:   [[3, 0], [-3, 6.5], [3, 6.5]],
  left:  [[3, 0], [3, 6.5], [4, 0]],
  right: [[3, 13], [3, -6.5], [4, 0]],
};

function inQuad(r, c, o, e1, e2) {
  const dr = r - o[0], dc = c - o[1];
  const det = e1[0] * e2[1] - e1[1] * e2[0];
  const s = (dr * e2[1] - dc * e2[0]) / det;
  const t = (e1[0] * dc - e1[1] * dr) / det;
  return s >= 0 && s <= 1 && t >= 0 && t <= 1;
}

// Anti aliasing.  A terminal cell can hold one character plus a foreground
// and a background colour, so a diagonal edge cannot be blended - but it can
// be split into four quarters that a block character covers.
const QUAD_GLYPH = {
  0:  ' ', 1: '▘', 2: '▝', 3: '▀', 4: '▖', 5: '▌', 6: '▟', 7: '▙',
  8:  '▗', 9: '▞', 10: '▐', 11: '▛', 12: '▄', 13: '▚', 14: '▜', 15: '█',
};
const EDGE = { cols: 2, rows: 2 };

// The floor tile is a perfect diamond (half width 7) so that neighbouring
// tiles share their edges exactly; the die artwork is half a cell narrower,
// which is not noticeable.
HEX_QUADS.tile = [[3, -7], [-3, 7], [3, 7]];

// For every face: map of "row,col" -> sub cell mask.  The masks depend on the
// edge mode, so they are built when the mode is set.
export const FACE_CELLS = {};
function buildFaceCells() {
  for (const face of Object.keys(HEX_QUADS)) {
    const [o, e1, e2] = HEX_QUADS[face];
    const cells = new Map();
    const corners = [o, [o[0] + e1[0], o[1] + e1[1]], [o[0] + e2[0], o[1] + e2[1]],
                     [o[0] + e1[0] + e2[0], o[1] + e1[1] + e2[1]]];
    let r0 = 1e9, r1 = -1e9, c0 = 1e9, c1 = -1e9;
    for (const [r, c] of corners) {
      r0 = Math.min(r0, r); r1 = Math.max(r1, r);
      c0 = Math.min(c0, c); c1 = Math.max(c1, c);
    }
    r0 = Math.floor(r0); r1 = Math.ceil(r1);
    c0 = Math.floor(c0); c1 = Math.ceil(c1);
    // the last row/column is included: a cell is named by its top left corner
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        let mask = 0;
        for (let i = 0; i < EDGE.rows; i++)
          for (let j = 0; j < EDGE.cols; j++) {
            // the centre of each sub cell
            const rr = r + (i + 0.5) / EDGE.rows;
            const cc = c + (j + 0.5) / EDGE.cols;
            if (inQuad(rr, cc, o, e1, e2)) mask |= 1 << (i * EDGE.cols + j);
          }
        if (mask) cells.set(r + ',' + c, { mask });
      }
    }
    FACE_CELLS[face] = cells;
  }
}

// Size of the offscreen canvas that holds the whole board.
// The top margin leaves room for KAWAMURA, who stands above his cell; the left
// margin keeps the dice and the player on the western edge from being clipped
// (the right edge already has the same six columns of room).
export const CANVAS_MARGIN_TOP = 12;
export const CANVAS_MARGIN_BOTTOM = 2;
export const CANVAS_MARGIN_LEFT = 12;
export function canvasGeom(size) {
  const span = (size - 1) * HEX_DX;
  const depth = (size - 1) * 2 * HEX_DY;
  return {
    ox: span + CANVAS_MARGIN_LEFT,
    oy: CANVAS_MARGIN_TOP,
    w: span * 2 + HEX_W + CANVAS_MARGIN_LEFT,
    h: depth + HEX_H + CANVAS_MARGIN_TOP + CANVAS_MARGIN_BOTTOM,
  };
}

buildFaceCells();

function paintMaskAt(cv, row, col, mask, color, sub = 0) {
  const rows = Math.floor(sub / 2);
  const half = sub % 2;
  const put = (r, m) => {
    if (!m || r < 0 || r >= cv.h || col < 0 || col >= cv.w) return;
    let painted = false;
    for (let i = 0; i < EDGE.cols * EDGE.rows; i++) {
      if (!(m & (1 << i))) continue;
      cv.q[i][r][col] = color;
      painted = true;
    }
    if (!painted) return;
    cv.ch[r][col] = null;
    cv.tc[r][col] = null;
  };
  if (!half) put(row + rows, mask);
  else {
    put(row + rows, (mask & 0b0011) << 2);
    put(row + rows + 1, (mask & 0b1100) >> 2);
  }
}

// Draw the board into a character canvas.
//
// Every cell keeps the colour of its four quarters plus an optional
// character.  opts:
//
//   groundColor : (x, y) => colour of a floor tile
//   faceColor   : (type, face) => colour of a die face
//   pipColor    : (type, value) => colour of the pips on that face
//   backdrop    : colour of everything that is not part of the board
//   aquiColor   : (part) => { fg, bg } of a KAWAMURA body part
export function makeCanvas(g, opts = {}) {
  const groundColor = opts.groundColor || (() => 240);
  const spawnColor = opts.spawnColor || (() => 226);
  const spawnPip = opts.spawnPip ?? 94;
  const matchColor = opts.matchColor || ((face, on) => 35);
  const oneColor = opts.oneColor || matchColor;
  const matchBlink = Math.floor(g.time * 2) % 2 === 0;
  // a vanishing "1" blinks half as fast as the green warning
  const oneBlink = Math.floor(g.time) % 2 === 0;
  const faceColor = opts.faceColor || (() => 250);
  const pipColor = opts.pipColor || (() => 235);
  const backdrop = opts.backdrop ?? 233;
  const aquiColor = opts.aquiColor || (() => ({}));

  const { ox, oy, w, h } = canvasGeom(g.size);
  const cv = {
    ox, oy, w, h,
    q: Array.from({ length: EDGE.cols * EDGE.rows }, () => Array.from({ length: h }, () => Array(w).fill(backdrop))),
    ch: Array.from({ length: h }, () => Array(w).fill(null)),
    tc: Array.from({ length: h }, () => Array(w).fill(null)),
  };

  // Paint a shape (cells with a quarter mask) with one colour.
  const fillShape = (cells, r0, c0, color, sub = 0, clipCell = null) => {
    for (const [key, info] of cells) {
      const [r, c] = key.split(',').map(Number);
      let mask = info.mask;
      if (clipCell) {
        mask = 0;
        for (let i = 0; i < EDGE.cols * EDGE.rows; i++) {
          if (!(info.mask & (1 << i))) continue;
          const rr = r + (i < 2 ? 0.25 : 0.75);
          const cc = c + (i % 2 ? 0.75 : 0.25);
          if (clipCell(rr, cc)) mask |= 1 << i;
        }
        if (!mask) continue;
      }
      paintMaskAt(cv, r0 + r, c0 + c, mask, color, sub);
    }
  };
  // put a character on top of a cell; bg fills the whole cell
  const putText = (row, col, ch, color, bg) => {
    if (row < 0 || row >= h || col < 0 || col >= w) return;
    cv.ch[row][col] = ch;
    cv.tc[row][col] = color ?? null;
    if (bg !== null && bg !== undefined) {
      for (let i = 0; i < 4; i++) cv.q[i][row][col] = bg;
    }
  };

  const cellOrigin = (x, y) => [ox + (x - y) * HEX_DX, oy + (x + y) * HEX_DY];
  // A die that is sinking goes down into the floor, so it does not hide the
  // face of the die behind it any more: that face shows up again while the
  // neighbour sinks.  (Nice-One sinks every "1" of the board at once, so
  // without this a "1" would lose both of its side faces at the same time
  // and only its top face would be left.)
  const blocks = (x, y) => {
    const d = g.grid.get(x + ',' + y);
    return !!d && !d.sinking;
  };

  // 2. the dice, back to front.  The player joins the same list, so nearer
  //    dice still occlude him; on equal depth he is drawn last, exactly like
  //    the canvas version does.
  const player = g.players[0];
  // The dice that will really vanish: a group of neighbouring dice with the
  // same value on top disappears when the group is at least as big as the
  // value (the rule of core.js resolveField).  Only those faces blink green.
  const vanishing = new Set();
  {
    const seen = new Set();
    for (const die of g.grid.values()) {
      if (die.spawning || seen.has(die.id)) continue;
      const v = die.state.top;
      const comp = [];
      const stack = [die];
      seen.add(die.id);
      let hasSinking = false;
      while (stack.length) {
        const d = stack.pop();
        comp.push(d);
        if (d.sinking) hasSinking = true;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const n = g.grid.get((d.x + dx) + ',' + (d.y + dy));
          if (!n || n.spawning || seen.has(n.id)) continue;
          if (n.state.top !== v) continue;
          seen.add(n.id);
          stack.push(n);
        }
      }
      const gone = (v >= 2 && comp.length >= v) || (hasSinking && comp.length >= 2);
      if (gone) for (const d of comp) vanishing.add(d.id);
    }
  }

  const roll = rollInfo(g);
  const slide = slideInfo(g);
  cv.roll = roll;
  cv.slide = slide;
  // The camera depth of the tumbling die follows its visual centre, not the
  // cell it still occupies in the game state.  Otherwise a die level with its
  // origin would be painted after (over) it even while it rolls away behind
  // that die.  The player rides the same die, just after it, but both stay
  // behind a tile that is one step nearer.
  const rollDepth = roll ? roll.center[0] + roll.center[1] + roll.center[2] - 0.5 : 0;
  const EPS = 1e-4;
  const items = [];
  for (let y = 0; y < g.size; y++)
    for (let x = 0; x < g.size; x++) {
      const die = g.grid.get(x + ',' + y);
      let depth = x + y;
      if (roll && die && roll.die.id === die.id) depth += rollDepth - 2 * EPS;
      else if (slide && die && slide.a.dieId === die.id
               && (slide.a.type === 'push' || slide.a.type === 'ice')) {
        // a pushed die also moves through the depth of the board
        depth += (slide.dx + slide.dy) * slide.e - EPS;
      }
      items.push({ x, y, depth, player: false });
    }
  if (player) {
    const depth = player.x + player.y + (roll ? rollDepth - EPS : 0);
    items.push({ x: player.x, y: player.y, depth, player: true });
  }
  items.sort((a, b) => a.depth - b.depth || (a.player ? 1 : 0) - (b.player ? 1 : 0));

  // 1. the floor: every cell gets its tile, the cubes are painted over them
  for (let y = 0; y < g.size; y++)
    for (let x = 0; x < g.size; x++) {
      const [cx, cy] = cellOrigin(x, y);
      fillShape(FACE_CELLS.tile, cy, cx, groundColor(x, y));
    }

  for (const item of items) {
    const { x, y } = item;
    const [cx, cy] = cellOrigin(x, y);
    if (item.player) {
      let ox = 0, oy = 0;
      if (roll) {
        // he rides the tumbling die: he sits on its top face
        const top = add3(roll.center, [0, 0.5, 0]);
        const now = proj(top);
        const rest = proj([0, 1, 0]);
        ox = now.x - rest.x;
        oy = now.y - rest.y;
      } else if (slide && (slide.a.type === 'walk' || slide.a.type === 'climb')) {
        ox = slide.dx * 7 * slide.e;
        oy = slide.dy * 3 * slide.e;
      }
      const rideDie = player.onDie ? g.grid.get(player.dieKey) : null;
      let rideSub = Math.floor(sinkDropOf(rideDie) * 2);
      if (slide && (slide.a.type === 'walk' || slide.a.type === 'climb')) {
        const targetDie = slide.a.type === 'climb' ? g.grid.get(slide.a.key) : null;
        rideSub = Math.round(rideSub * (1 - slide.e) + Math.floor(sinkDropOf(targetDie) * 2) * slide.e);
      }
      drawAqui(cv, player, g, putText, cellOrigin, aquiColor, ox, oy, rideSub);
      continue;
    }
    const die = g.grid.get(x + ',' + y);
    if (!die) continue;
    if (roll && roll.die.id === die.id) {
      // This die is tumbling: it is drawn in 3D while it rolls over its
      // front contact edge, so it tips into the next cell instead of spinning
      // on the spot - the die does not hop.
      const [bx, by] = cellOrigin(x, y);
      // the 14-wide hexagon is centred half a cell to the right of the tile
      // origin, and the cube stands on the tile centre three rows below it
      const ox = bx + 0.5;
      const oy = by + 3;
      const colors = {
        top: faceColor(die.type, 'top'),
        left: faceColor(die.type, 'left'),
        right: faceColor(die.type, 'right'),
        side: faceColor(die.type, 'left'),
      };
      drawTumblingDie(cv, roll.basis, ox, oy, roll.center, colors, (v) => pipColor(die.type, v));
      continue;
    }
    // The cube rests on the floor tile: one cube height above it, and half
    // a cell to the left, because the hexagon artwork is 14 columns wide
    // and its centre falls between two columns.  A die that is pushed (or
    // that slides over ice) moves along with the action.
    let dx = cx - 6;
    let dy = cy - HEX_CUBE_H;
    if (slide && (slide.a.type === 'push' || slide.a.type === 'ice') && slide.a.dieId === die.id) {
      dx += Math.round(slide.dx * 7 * slide.e);
      dy += Math.round(slide.dy * 3 * slide.e);
    }
    const sinkSub = Math.floor(sinkDropOf(die) * 2);
    const sinkRows = sinkSub / 2;
    const pipDy = dy + Math.round(sinkRows);
    const faded = die.sinking || die.spawning;
    // faces: the south-west face is hidden by the neighbour at (x, y+1),
    // the south-east face by the neighbour at (x+1, y).
    const faces = [
      ['top', die.spawning ? 0 : die.state.top, true],
      ['left', die.spawning ? 0 : die.state.south, !blocks(x, y + 1)],
      ['right', die.spawning ? 0 : die.state.east, !blocks(x + 1, y)],
    ];
    for (const [face, value, visible] of faces) {
      if (!visible) continue;
      // a die that is about to appear blinks in gold - from the warning
      // until it really shows up
      const warn = die.spawning;
      const blink = warn && (Math.floor(g.time * 5) % 2 === 0);
      // A die that is going to vanish blinks green (it is grey while it
      // sinks, so the green has to come first), a die that is about to
      // appear blinks in gold and everything else keeps its normal colour.
      // A vanishing "1" blinks pearl red-purple, more slowly than the green
      // warning; it keeps that blink while it sinks, including a lone "1" that
      // only disappears through Nice-One.
      const isOne = die.state.top === 1;
      const going = vanishing.has(die.id) || (isOne && die.sinking);
      let color;
      if (warn) color = spawnColor(face, blink);
      else if (going && isOne) color = oneColor(face, oneBlink);
      else if (going) color = matchColor(face, matchBlink);
      else if (faded) color = 238;
      else color = faceColor(die.type, face);
      const sinkClip = sinkRows > 0 ? (r, c) => faceHeight(face, r, c) > sinkRows : null;
      fillShape(FACE_CELLS[face], dy, dx, color, sinkSub, sinkClip);
      // pips keep their own colour, also while the die is fading
      const pip = warn ? spawnPip : pipColor(die.type, value);
      const showPip = (r, c) => sinkRows <= 0 || faceHeight(face, r + 0.5, c + 0.5) > sinkRows;
      if (!value) {
        // not there yet: a question mark in the middle of the face
        const [c, r] = FACE_CENTER[face];
        putText(pipDy + r, dx + c, '?', pip, null);
        continue;
      }
      for (const [u, v] of HEX_PIPS[value] || []) {
        const [c, r] = HEX_PROJ[face](u, v);
        if (showPip(r, c)) putText(pipDy + r, dx + c, PIP_DOT, pip, null);
      }
    }
  }
  // Where KAWAMURA is drawn right now: on a tumbling die he rides its top
  // face, while walking he slides to the next cell.
  if (slide && (slide.a.type === 'walk' || slide.a.type === 'climb' || slide.a.type === 'roll')) {
    // the player rides the die over to the next cell
    cv.playerOffset = { x: slide.dx * 7 * slide.e, y: slide.dy * 3 * slide.e };
  } else if (false) {
    cv.playerOffset = { x: slide.dx * 7 * slide.e, y: slide.dy * 3 * slide.e };
  } else {
    cv.playerOffset = { x: 0, y: 0 };
  }
  return cv;
}

// Render a cell: one background colour plus an optional quarter block or
// character in the foreground.
export function cellStyle(cv, row, col) {
  const q = [];
  for (let i = 0; i < EDGE.cols * EDGE.rows; i++) q.push(cv.q[i][row][col]);
  const counts = new Map();
  for (const c of q) if (c !== null) counts.set(c, (counts.get(c) || 0) + 1);
  const text = cv.ch[row][col];
  if (counts.size === 0) {
    return { ch: text || ' ', fg: cv.tc[row][col], bg: null };
  }
  const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1]);
  const bg = sorted[0][0];
  if (sorted.length === 1 || text) {
    return { ch: text || ' ', fg: text ? cv.tc[row][col] : null, bg };
  }
  const fg = sorted[1][0];
  let mask = 0;
  for (let i = 0; i < EDGE.cols * EDGE.rows; i++) if (q[i] === fg) mask |= 1 << i;
  return { ch: QUAD_GLYPH[mask], fg, bg };
}


// While something moves, its position is interpolated: a pushed die slides,
// the player walks and the rolling die tumbles over to the next cell.
function slideInfo(g) {
  const a = g.action;
  if (!a || !a.duration) return null;
  const t = Math.max(0, Math.min(1, 1 - a.remaining / a.duration));
  const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;   // ease in out
  const d = DIRS[a.dir] || [0, 0];
  return { a, t, e, dx: d[0], dy: d[1] };
}

// The roll animation.  A tumbling die pivots around the edge it rests on
// (the contact edge between its cell and the next one), so the rotation and
// the move are one movement: the die tips over its front edge and lands on the
// next cell.  Rotating around the centre of the tile instead would make it
// wobble on the spot and slide at the same time, which looks like a detour.
function rollInfo(g) {
  const a = g.action;
  if (!a || a.type !== 'roll' || !a.duration) return null;
  const t = Math.max(0, Math.min(1, 1 - a.remaining / a.duration));
  const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;   // ease in out
  const axis = ROLL_AXIS[a.dir];
  const die = [...g.grid.values()].find((d) => d.id === a.dieId);
  if (!die || !axis) return null;
  const angle = axis.sg * e * Math.PI / 2;
  const basis = rotateBasis(basisFromState(die.state), axis.ax, angle);
  // the direction of the roll in world coordinates (+X east, +Z south)
  const d = DIRS[a.dir];
  const wx = d[0], wz = d[1];
  // the pivot is the contact edge: half a cell ahead, on the ground
  const pivot = [wx * 0.5, 0, wz * 0.5];
  // the cube centre starts half a cube above the tile centre, i.e. at the
  // vector `off` from the pivot.  Both the centre and the basis turn about the
  // fixed pivot, so the die tips over the edge and lands one cell ahead.
  const off = [-wx * 0.5, 0.5, -wz * 0.5];
  const center = add3(pivot, rotateVec(off, axis.ax, angle));
  return { die, basis, t, e, pivot, off, center };
}

// Fill a projected quad (a parallelogram on screen) with one colour.  The
// quarter of every cell inside the quad is painted, so the edges follow the
// real outline just like the hexagon artwork.
function fillQuad(cv, p0, p1, p2, p3, color) {
  const ux = p1.x - p0.x, uy = p1.y - p0.y;      // one edge
  const vx = p3.x - p0.x, vy = p3.y - p0.y;      // the other edge
  const det = ux * vy - uy * vx;
  if (!det) return;
  const cmin = Math.max(0, Math.floor(Math.min(p0.x, p1.x, p2.x, p3.x)));
  const cmax = Math.min(cv.w - 1, Math.ceil(Math.max(p0.x, p1.x, p2.x, p3.x)));
  const rmin = Math.max(0, Math.floor(Math.min(p0.y, p1.y, p2.y, p3.y)));
  const rmax = Math.min(cv.h - 1, Math.ceil(Math.max(p0.y, p1.y, p2.y, p3.y)));
  for (let r = rmin; r <= rmax; r++) {
    for (let c = cmin; c <= cmax; c++) {
      for (let i = 0; i < EDGE.rows; i++) {
        for (let j = 0; j < EDGE.cols; j++) {
          const sr = r + (i + 0.5) / EDGE.rows - p0.y;
          const sc = c + (j + 0.5) / EDGE.cols - p0.x;
          const a = (sc * vy - sr * vx) / det;   // the u coordinate
          const b = (sr * ux - sc * uy) / det;   // the w coordinate
          if (a < 0 || a > 1 || b < 0 || b > 1) continue;
          cv.q[i * EDGE.cols + j][r][c] = color;
        }
      }
    }
  }
}

// Draw a die that is tumbling: the three faces towards the camera are
// projected from the rotated basis and painted as quads.
function drawTumblingDie(cv, basis, ox, oy, center, colors, pipColor) {
  const vis = [];
  for (const f of CUBE_FACES) {
    const nw = toWorld(basis, f.n);
    const depth = nw[0] * CAM[0] + nw[1] * CAM[1] + nw[2] * CAM[2];
    if (depth <= 0.02) continue;
    // the cube is one cell wide, so its local coordinates run from -0.5 to
    // 0.5 on every axis.  `center` is the world-space centre of the tumbling
    // cube, already turned about the contact edge.
    const o = [
      (f.n[0] - f.u[0] - f.w[0]) * 0.5,
      (f.n[1] - f.u[1] - f.w[1]) * 0.5,
      (f.n[2] - f.u[2] - f.w[2]) * 0.5,
    ];
    const ou = [o[0] + f.u[0], o[1] + f.u[1], o[2] + f.u[2]];
    const ow = [o[0] + f.w[0], o[1] + f.w[1], o[2] + f.w[2]];
    const c0 = proj(add3(toWorld(basis, o), center));
    const cu = proj(add3(toWorld(basis, ou), center));
    const cw = proj(add3(toWorld(basis, ow), center));
    vis.push({ f, c0, cu, cw, depth });
  }
  vis.sort((a, b) => a.depth - b.depth);
  for (const { f, c0, cu, cw } of vis) {
    const value = LOCAL_VALUE[f.key];
    const p0 = { x: ox + c0.x, y: oy + c0.y };
    const p1 = { x: ox + cu.x, y: oy + cu.y };
    const p3 = { x: ox + cw.x, y: oy + cw.y };
    const p2 = { x: p1.x + p3.x - p0.x, y: p1.y + p3.y - p0.y };
    const nw = toWorld(basis, f.n);
    // Which of the three visible sides of the die is this face?  The world
    // axes are: +X east (the right face), +Y up (the top), +Z south (the left).
    let col;
    if (nw[1] > 0.7) col = colors.top;
    else if (nw[0] > 0.7) col = colors.right;
    else if (nw[2] > 0.7) col = colors.left;
    else col = colors.side;
    fillQuad(cv, p0, p1, p2, p3, col);
    // the pips follow the face
    const ux = p1.x - p0.x, uy = p1.y - p0.y;
    const vx = p3.x - p0.x, vy = p3.y - p0.y;
    for (const [pu, pw] of FACE_PIPS[value] || []) {
      const px = Math.round(p0.x + ux * pu + vx * pw);
      const py = Math.round(p0.y + uy * pu + vy * pw);
      if (py < 0 || py >= cv.h || px < 0 || px >= cv.w) continue;
      cv.ch[py][px] = PIP_DOT;
      cv.tc[py][px] = pipColor(value);
    }
  }
}

// --- 3D die (for the roll animation) ------------------------------------------
// The same idea as the canvas version (~/dice2d/public/game.js): the die
// carries a 3 axis basis, the face values are welded to the local axes, and a
// roll turns the basis by 90 degrees.  The projection is scaled so that a
// tumbling die has exactly the proportions of the hexagon artwork.
const PROJ_X = 7, PROJ_Z = 3, PROJ_Y = 4;
const CAM = [1, 1, 1];
const ROLL_AXIS = {
  N: { ax: [1, 0, 0], sg: -1 },
  S: { ax: [1, 0, 0], sg: 1 },
  E: { ax: [0, 0, 1], sg: -1 },
  W: { ax: [0, 0, 1], sg: 1 },
};
// the six faces of the cube: normal, u axis, w axis
// the value that sits on each local axis of the die
const LOCAL_VALUE = { x: 3, nx: 4, y: 1, ny: 6, z: 2, nz: 5 };
const CUBE_H = 4;
const CUBE_FACES = [
  { n: [1, 0, 0], u: [0, 1, 0], w: [0, 0, 1], key: 'x' },
  { n: [-1, 0, 0], u: [0, 0, 1], w: [0, 1, 0], key: 'nx' },
  { n: [0, 1, 0], u: [0, 0, 1], w: [1, 0, 0], key: 'y' },
  { n: [0, -1, 0], u: [1, 0, 0], w: [0, 0, 1], key: 'ny' },
  { n: [0, 0, 1], u: [1, 0, 0], w: [0, 1, 0], key: 'z' },
  { n: [0, 0, -1], u: [0, 1, 0], w: [1, 0, 0], key: 'nz' },
];
// the pips of a face in the unit square of that face
const FACE_PIPS = {
  1: [[0.5, 0.5]],
  2: [[0.26, 0.26], [0.74, 0.74]],
  3: [[0.24, 0.24], [0.5, 0.5], [0.76, 0.76]],
  4: [[0.27, 0.27], [0.73, 0.27], [0.27, 0.73], [0.73, 0.73]],
  5: [[0.27, 0.27], [0.73, 0.27], [0.5, 0.5], [0.27, 0.73], [0.73, 0.73]],
  6: [[0.27, 0.22], [0.27, 0.5], [0.27, 0.78], [0.73, 0.22], [0.73, 0.5], [0.73, 0.78]],
};

function normalOfValue(v, st) {
  if (st.top === v) return [0, 1, 0];
  if (st.bottom === v) return [0, -1, 0];
  if (st.north === v) return [0, 0, -1];
  if (st.south === v) return [0, 0, 1];
  if (st.east === v) return [1, 0, 0];
  return [-1, 0, 0];
}
// the world direction of the die's local axes
function basisFromState(st) {
  return { x: normalOfValue(3, st), y: normalOfValue(1, st), z: normalOfValue(2, st) };
}
function rotateVec(v, ax, ang) {
  const c = Math.cos(ang), sn = Math.sin(ang), ic = 1 - c;
  const d = ax[0] * v[0] + ax[1] * v[1] + ax[2] * v[2];
  const cx = ax[1] * v[2] - ax[2] * v[1];
  const cy = ax[2] * v[0] - ax[0] * v[2];
  const cz = ax[0] * v[1] - ax[1] * v[0];
  return [
    v[0] * c + cx * sn + ax[0] * d * ic,
    v[1] * c + cy * sn + ax[1] * d * ic,
    v[2] * c + cz * sn + ax[2] * d * ic,
  ];
}
function rotateBasis(b, ax, ang) {
  const out = {};
  for (const k of ['x', 'y', 'z']) out[k] = rotateVec(b[k], ax, ang);
  return out;
}
export const add3 = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
export function toWorld(basis, p) {
  return [
    p[0] * basis.x[0] + p[1] * basis.y[0] + p[2] * basis.z[0],
    p[0] * basis.x[1] + p[1] * basis.y[1] + p[2] * basis.z[1],
    p[0] * basis.x[2] + p[1] * basis.y[2] + p[2] * basis.z[2],
  ];
}
// world -> screen (columns to the right, rows down)
export function proj(w) {
  return { x: (w[0] - w[2]) * PROJ_X, y: (w[0] + w[2]) * PROJ_Z - w[1] * PROJ_Y };
}
// --- KAWAMURA (the player) -------------------------------------------------------
// The little horned creature of the canvas version (~/dice2d/public/game.js):
// sky blue body, red horns and limbs.  Like the dice it is drawn as filled
// shapes with quarter block borders, so the whole board shares one look.

const shapeCells = (test, r0, r1, c0, c1) => {
  const cells = new Map();
  for (let r = r0; r <= r1; r++) {
    for (let c = c0; c <= c1; c++) {
      let mask = 0;
      if (test(r + 0.25, c + 0.25)) mask |= 1;
      if (test(r + 0.25, c + 0.75)) mask |= 2;
      if (test(r + 0.75, c + 0.25)) mask |= 4;
      if (test(r + 0.75, c + 0.75)) mask |= 8;
      if (mask) cells.set(r + ',' + c, { mask });
    }
  }
  return cells;
};
// a rectangle in cell coordinates
const rect = (r0, r1, c0, c1) => (r, c) => r >= r0 && r <= r1 && c >= c0 && c <= c1;
const ellipse = (cr, cc, ry, rx) => (r, c) => {
  const dy = (r - cr) / ry, dx = (c - cc) / rx;
  return dx * dx + dy * dy <= 1;
};
const segment = (r0, c0, r1, c1, w) => (r, c) => {
  const dr = r1 - r0, dc = c1 - c0;
  const len = dr * dr + dc * dc;
  let t = len ? ((r - r0) * dr + (c - c0) * dc) / len : 0;
  t = Math.max(0, Math.min(1, t));
  const pr = r0 + dr * t - r, pc = c0 + dc * t - c;
  return pr * pr + pc * pc <= w * w;
};

// The shapes of the character, in a 11x7 sprite whose feet are on row 10.
// Every shape is drawn twice: once dilated in the dark outline colour and
// once in its own colour, which gives the figure its contour.
export function kawamuraShapes(dir, swing) {
  const fx = dir === 'E' ? 1 : dir === 'W' ? -1 : 0;
  const back = dir === 'N';
  const head = fx * 0.9;
  const arm = swing * 0.9;
  const leg = swing * 0.7;
  const OUT = 0.26;
  // The eyes are burnt brown.  They are drawn like every other shape: as a
  // filled area of half a cell, so they take as little room as possible.
  // Facing the camera there are two, a cell apart; seen from the side only
  // one; from behind none at all.
  const eyes = [];
  if (dir === 'S') eyes.push(2, 3);
  else if (dir === 'E') eyes.push(4);
  else if (dir === 'W') eyes.push(1);
  const defs = [
    // long legs, spread wide so that they frame the pips of the die
    { part: 'limb', shape: (d) => segment(6.3, 1.5, 9.2, 0.7 - leg, 0.32 + d), box: [6, 10, 0, 7] },
    { part: 'limb', shape: (d) => segment(6.3, 4.5, 9.2, 5.3 + leg, 0.32 + d), box: [6, 10, 0, 7] },
    { part: 'limb', shape: (d) => segment(4.9, 1.7, 6.1, 0.6 - arm, 0.29 + d), box: [4, 7, 0, 7] },
    { part: 'limb', shape: (d) => segment(4.9, 4.3, 6.1, 5.4 + arm, 0.29 + d), box: [4, 7, 0, 7] },
    { part: 'body', shape: (d) => ellipse(5.2, 3, 1.4 + d, 1.75 + d), box: [3, 8, 0, 7] },
    // a smaller head, the same water blue from every side
    { part: 'body', shape: (d) => ellipse(2.7, 3 + head, 1.15 + d, 1.6 + d), box: [1, 4, 0, 7] },
    // the horns are painted over the head, so they are not cut off by its
    // contour: they start right at the edge of the head
    { part: 'horn', shape: (d) => segment(1.9, 1.9 + head, 0.3, 0.6 + head * 1.3, 0.28 + d), box: [0, 3, 0, 7] },
    { part: 'horn', shape: (d) => segment(1.9, 4.1 + head, 0.3, 5.4 + head * 1.3, 0.28 + d), box: [0, 3, 0, 7] },
  ];
  for (const col of eyes) {
    defs.push({
      part: 'eye',
      // as thin as possible: the left half of the upper half of a cell
      shape: () => rect(2.0, 2.5, col, col + 0.5),
      box: [1, 4, 0, 7],
    });
  }
  const shapes = [];
  // the dark contour of every part first, then the colours on top of it
  for (const d of defs) {
    const [r0, r1, c0, c1] = d.box;
    shapes.push({ part: d.part, outline: true, cells: shapeCells(d.shape(OUT), r0, r1, c0, c1) });
  }
  for (const d of defs) {
    const [r0, r1, c0, c1] = d.box;
    shapes.push({ part: d.part, cells: shapeCells(d.shape(0), r0, r1, c0, c1) });
  }
  return shapes;
}

// Eyes: a character on top of the head.
// Draw KAWAMURA standing on the cell he occupies.  He stands on the back edge of
// the top face so the pips of the die he rides stay readable.
function drawAqui(cv, player, g, putText, cellOrigin, aquiColor, offX = 0, offY = 0, subRows = 0) {
  const [cx, cy] = cellOrigin(player.x, player.y);
  const action = g.action;
  const t = action && action.duration ? 1 - action.remaining / action.duration : 0;
  const swing = action ? Math.sin(t * Math.PI * 2) : 0;
  const shapes = kawamuraShapes(player.dir, swing);
  // The sprite's feet are on row 9.  He stands so that his ankles are one row
  // above the "1" pip of the die (the top face's centre), and spreads his legs
  // wide, so the pips of the die stay visible between them.
  const FOOT = 9;
  const baseRow = player.onDie ? cy - 2 : cy + 2;
  const left = cx - 3;                   // centred on the top face
  for (const shape of shapes) {
    const style = aquiColor(shape.part) || {};
    // the contour of a part is drawn in the dark shade of that part's own
    // colour, so legs get a dark red and the body a dark water blue
    const bg = (shape.outline ? style.line : style.bg) ?? null;
    for (const [key, info] of shape.cells) {
      const [r, c] = key.split(',').map(Number);
      const row = Math.round(baseRow - FOOT + r + offY), col = Math.round(left + c + offX);
      if (bg === null) {
        // plain text: draw the shape with a character
        const drawRow = row + Math.round(subRows / 2);
        if (drawRow < 0 || drawRow >= cv.h || col < 0 || col >= cv.w) continue;
        if (style.char) putText(drawRow, col, shape.outline ? (style.lineChar ?? '.') : style.char, null, null);
        continue;
      }
      paintMaskAt(cv, row, col, info.mask, bg, subRows);
    }
  }
}

// --- camera ---------------------------------------------------------------------
// The board is bigger than the terminal, so the terminal shows a window of it.
// The window follows KAWAMURA, but lazily: it stays where it is while he walks
// around inside it and only scrolls when he reaches its edge.  The scroll is
// the smallest one that brings him fully back into view, so the view moves as
// little as possible.
const CAM_SPEED = 0.7;        // how fast the window glides to its new place

// A camera keeps the position of the window in canvas cells.
export function makeCamera() {
  return { x: null, y: null, tx: 0, ty: 0 };
}

// Where KAWAMURA is drawn: the box the camera keeps on the screen.  It is
// the lower half of his sprite only: the upper half (head and horns) may be
// cut off by the top of the window, so the camera has to scroll much less.
function spriteBox(cv, player) {
  const cx = cv.ox + (player.x - player.y) * HEX_DX;
  const cy = cv.oy + (player.x + player.y) * HEX_DY;
  // The sprite is 11 rows tall and its feet are on row 10, so it reaches from
  // baseRow - 9 to baseRow + 1.  On a die he stands further up.
  const baseRow = player.onDie ? cy - 2 : cy + 2;
  return {
    left: cx - 3, right: cx + 4,
    top: baseRow - 4, bottom: baseRow + 1,
  };
}

// Window of the canvas that is shown on the terminal.  With a camera the
// window only moves when the player reaches its edge; without one it is
// simply centred on him.
export function viewportFor(cv, player, termW, termH, chrome = 7, cam = null) {
  const winW = Math.min(cv.w, Math.max(20, termW));
  const winH = Math.min(cv.h, Math.max(8, termH - chrome));
  const maxX = Math.max(0, cv.w - winW);
  const maxY = Math.max(0, cv.h - winH);
  const box = spriteBox(cv, player);

  if (!cam) {
    const winX = Math.max(0, Math.min(maxX, Math.round((box.left + box.right) / 2 - winW / 2)));
    const winY = Math.max(0, Math.min(maxY, Math.round((box.top + box.bottom) / 2 - winH / 2)));
    return { winX, winY, winW, winH };
  }

  if (cam.x === null) {
    // the first frame: the window opens on the player
    cam.x = Math.max(0, Math.min(maxX, (box.left + box.right) / 2 - winW / 2));
    cam.y = Math.max(0, Math.min(maxY, (box.top + box.bottom) / 2 - winH / 2));
    cam.tx = cam.x; cam.ty = cam.y;
  } else {
    // The dead zone: as long as KAWAMURA fits into the window the view does
    // not move at all.  Only when he reaches the edge of the window does it
    // scroll, and then by the smallest amount that brings him back in.
    let tx = cam.x;
    if (box.left < cam.x) tx = box.left;
    else if (box.right > cam.x + winW - 1) tx = box.right - winW + 1;
    let ty = cam.y;
    if (box.top < cam.y) ty = box.top;
    else if (box.bottom > cam.y + winH - 1) ty = box.bottom - winH + 1;
    cam.tx = Math.max(0, Math.min(maxX, tx));
    cam.ty = Math.max(0, Math.min(maxY, ty));
    // the window glides to its new place instead of jumping
    cam.x += (cam.tx - cam.x) * CAM_SPEED;
    cam.y += (cam.ty - cam.y) * CAM_SPEED;
    if (Math.abs(cam.tx - cam.x) < 0.5) cam.x = cam.tx;
    if (Math.abs(cam.ty - cam.y) < 0.5) cam.y = cam.ty;
  }
  const winX = Math.max(0, Math.min(maxX, Math.round(cam.x)));
  const winY = Math.max(0, Math.min(maxY, Math.round(cam.y)));
  return { winX, winY, winW, winH };
}

// Plain text of a canvas region (used for tests / previews).
export function canvasText(cv, x0 = 0, y0 = 0, w = cv.w, h = cv.h) {
  const out = [];
  for (let r = 0; r < h; r++) {
    let line = '';
    for (let c = 0; c < w; c++) line += cellStyle(cv, y0 + r, x0 + c).ch;
    out.push(line.replace(/\s+$/, ''));
  }
  return out.join('\n');
}
