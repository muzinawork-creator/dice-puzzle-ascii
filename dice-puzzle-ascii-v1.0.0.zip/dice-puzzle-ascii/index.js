#!/usr/bin/env node
import { Game, DICE_TYPE } from './core.js';
import { makeCanvas, viewportFor, cellStyle, makeCamera } from './render.js';

const useColor = !process.env.NO_COLOR && (process.stdout.isTTY || process.env.FORCE_COLOR);

// Which die types spawn.  The startup setting is only the initial choice; the
// title screen can cycle through the presets.  A comma separated list picks
// randomly from it; "random" means every type.
// Example: --dice=wood,ice  or  DICE_TYPE=random
const DICE_TYPES = Object.values(DICE_TYPE);
const diceSetting = (() => {
  const arg = process.argv.find((a) => a.startsWith('--dice='));
  return (arg ? arg.slice('--dice='.length) : process.env.DICE_TYPE) || 'normal';
})();
const startupPool = (() => {
  const raw = diceSetting.toLowerCase().trim();
  if (raw === 'random' || raw === 'mix' || raw === 'all') return DICE_TYPES;
  const list = [...new Set(raw.split(',').map((s) => s.trim()).filter(Boolean))];
  const valid = list.filter((t) => DICE_TYPES.includes(t));
  return valid.length ? valid : ['normal'];
})();
const DICE_PRESETS = DICE_TYPES.map((t) => [t, [t]]);
DICE_PRESETS.push(['random', DICE_TYPES]);
let diceIndex = DICE_PRESETS.findIndex(([, pool]) =>
  pool.length === startupPool.length && pool.every((t, i) => t === startupPool[i]));
if (diceIndex < 0) {
  DICE_PRESETS.push([startupPool.join('+'), startupPool]);
  diceIndex = DICE_PRESETS.length - 1;
}
let [diceLabel, dicePool] = DICE_PRESETS[diceIndex];
function cycleDice(step) {
  diceIndex = (diceIndex + step + DICE_PRESETS.length) % DICE_PRESETS.length;
  [diceLabel, dicePool] = DICE_PRESETS[diceIndex];
}

const ST = (code) => (useColor ? `\x1b[${code}m` : '');
const RST = useColor ? '\x1b[0m' : '';
const bold = (s) => ST(1)+s+RST;
const dim = (s) => ST(2)+s+RST;
const red = (s) => ST(31)+s+RST;
const yellow = (s) => ST(33)+s+RST;
const magenta = (s) => ST(35)+s+RST;
const cyan = (s) => ST(36)+s+RST;
const white = (s) => ST(37)+s+RST;
const gray = (s) => ST(90)+s+RST;

const TYPE_COLOR = { normal: ST(37), wood: ST(33), ice: ST(36), stone: ST(90), iron: ST(31) };

// --- shading ------------------------------------------------------------------
// 256 colour palette.  The board is shaded instead of outlined: every floor
// tile is a filled diamond and every die is a cube whose three faces have
// their own brightness (top = brightest, right = darkest).  Diagonal borders
// are drawn with quarter block characters, so they follow the real edge.

const BACKDROP = 232;                       // everything around the board
const GROUND_A = 236, GROUND_B = 239;        // floor tiles, subtle checker
const groundColor = (x, y) => ((x + y) % 2 === 0 ? GROUND_A : GROUND_B);

// dice: [top, left, right]
const DIE_PALETTE = {
  normal: [255, 249, 241],
  wood:   [229, 220, 208],
  ice:    [195, 152, 117],
  stone:  [248, 241, 235],
  iron:   [210, 201, 160],
};
const faceColor = (type, face) => (DIE_PALETTE[type] || DIE_PALETTE.normal)[
  face === 'top' ? 0 : face === 'left' ? 1 : 2];

// The colour of a pip tells the value of its face (same idea as the canvas
// version, which tints every face with FACE_COLORS[value]).  The colours are
// the pastel tints of ~/dice2d/public/game.js, darkened so the dots stay
// readable on the bright faces.
const VALUE_COLOR = { 1: 21, 2: 136, 3: 125, 4: 131, 5: 102, 6: 71 };
// The gold shades a die that is about to appear blinks through.
const SPAWN_COLORS = {
  top:   [220, 136],  // #ffd700 / #af8700
  left:  [178, 94],   // #d78700 / #875f00
  right: [136, 52],   // #af8700 / #5f5f00
};
// The green shades a vanishing die blinks through.  Each face has its own
// pair, so the left side always stays brighter than the right one.  Green is
// used instead of water blue so a vanishing die does not look like an ice die.
const MATCH_COLORS = {
  top:   [121, 35],  // #87ffaf / #00af5f
  left:  [84, 29],   // #5fff87 / #00875f
  right: [48, 28],   // #00ff87 / #008700
};
// A vanishing "1" blinks in a pearl red-purple, more slowly than the green
// warning.  Each face alternates a pale pink pearl with a deep red-purple, so
// the blink is clearly visible without looking grey.
const ONE_COLORS = {
  top:   [218, 161],  // #ffafd7 / #d7005f
  left:  [212, 126],  // #ff87d7 / #af0087
  right: [205, 89],   // #ff5faf / #87005f
};
const pipColor = (type, value) => VALUE_COLOR[value] ?? 102;


// KAWAMURA palette (lifted from the canvas version ~/dice2d/public/game.js)
// Each part is { fg, bg }; a missing colour keeps the one underneath.
// Every part has its own colour and its own dark shade, which is used for the
// contour of that part.
const KAWAMURA_COLOR = {
  body: { bg: 117, line: 25 },   // water blue body, darker water blue contour
  limb: { bg: 203, line: 88 },   // red arms and legs, darker red contour
  horn: { bg: 131, line: 94 },   // brown horns, darker brown contour
  eye:  { bg: 94,  line: 52 },  // burnt brown eyes, darker brown contour
};
// plain text fallback
const KAWAMURA_MONO = {
  body: { char: '#', lineChar: '.' },
  limb: { char: '=', lineChar: '.' },
  horn: { char: '^', lineChar: '.' },
  eye:  { char: '@', lineChar: '.' },
};

const REASON = { full: 'The board is full', stuck: 'You cannot move any more', time: 'Time is up' };

let state = 'title';
let mode = 'endless';
let game = null;
// The event log.  It is shown on a single line under the board: the newest
// event stands on the left, older ones follow to the right and are pushed
// out of the line when it overflows.
let messages = [];
const MAX_MSG = 24;
const pushMsg = (m) => { messages.unshift(m); if (messages.length > MAX_MSG) messages.pop(); };

// How many columns a character takes in the terminal.  Japanese characters
// are two columns wide, everything else is one.
const WIDE_RE = /[\u1100-\u115F\u2E80-\u303E\u3041-\u33FF\u3400-\u4DBF\u4E00-\u9FFF\uA000-\uA4CF\uAC00-\uD7A3\uF900-\uFAFF\uFE30-\uFE6F\uFF00-\uFF60\uFFE0-\uFFE6]/;
const charWidth = (ch) => (WIDE_RE.test(ch) ? 2 : 1);
const textWidth = (s) => {
  let n = 0;
  for (const ch of s) n += charWidth(ch);
  return n;
};
// Cut a text to the given number of columns, with an ellipsis when it does
// not fit.
const clipText = (s, width) => {
  let n = 0, out = '';
  for (const ch of s) {
    const w = charWidth(ch);
    if (n + w > width - 1) return out + '…';
    out += ch; n += w;
  }
  return out;
};
// The ticker line: the newest event first, left aligned, older events pushed
// out to the right when the line is full.
function tickerText(width) {
  let out = '';
  for (const m of messages) {
    const add = (out ? '  ' : '') + m;
    if (textWidth(out) + textWidth(add) <= width) { out += add; continue; }
    if (!out) out = clipText(m, width);
    break;
  }
  return out;
}

function startGame(m) {
  mode = m || mode;
  messages = [];
  resetCamera();
  const opts = mode === 'time' ? { maxTime: 180 } : {};
  const seed = process.env.DICE_SEED !== undefined ? Number(process.env.DICE_SEED) : (Math.random() * 1e9) | 0;
  const diceFn = dicePool.length === 1
    ? () => dicePool[0]
    : (g) => dicePool[Math.floor(g.rng() * dicePool.length)];
  game = new Game({ size: 7, initialDice: 6, initialSpawnDelay: 1.2, spawnInterval: 3.0, seed, diceFn, ...opts });
  state = 'playing';
}
const toTitle = () => { state = 'title'; game = null; messages = []; };

function processEvents() {
  if (!game) return;
  for (const e of game.events) {
    switch (e.type) {
      case 'vanish': pushMsg(`MATCH ${e.face} x${e.links}  +${e.points}`); break;
      case 'chain': pushMsg(`COMBO ${e.face} x${e.links}  +${e.points}`); break;
      case 'nice': pushMsg(`NICE ONE x${e.links}  +${e.points}`); break;
      case 'levelup': pushMsg(`LEVEL UP -> ${e.level}`); break;
      case 'gameover': state = 'gameover'; break;
      case 'removed': if (e.wasStanding) pushMsg('The die under you is gone'); break;
    }
  }
  game.events.length = 0;
}

function input(dir, shift) {
  if (state === 'title') { startGame('endless'); return; }
  if (state === 'gameover') { startGame(mode); return; }
  if (state !== 'playing' || !game) return;
  game.pushInput(dir, shift);
}

// --- terminal lifecycle -------------------------------------------------------
let cleaned = false;
function cleanup() {
  if (cleaned) return;
  cleaned = true;
  try { process.stdin.setRawMode?.(false); } catch {}
  process.stdin.pause();
  process.stdout.write('\x1b[0m\x1b[?25h\x1b[?1049l');
}
const quit = (code = 0) => { cleanup(); process.exit(code); };
function enterFullscreen() { if (!cleaned) process.stdout.write('\x1b[?1049h\x1b[?25l'); }
process.on('exit', cleanup);
for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) process.on(sig, () => quit(0));

// --- input --------------------------------------------------------------------
const ARROWS = { A: 'N', B: 'S', C: 'E', D: 'W' };
const ARROW_RE = /^\x1b(?:\[\d*;?(\d*)|O)([ABCD])$/;
process.stdin.setRawMode?.(true);
process.stdin.resume();
process.stdin.setEncoding('utf8');
process.stdin.on('data', (s) => {
  if (s === '\x03') { quit(0); return; }
  if (s === '\x1b') { if (state === 'playing') toTitle(); else quit(0); return; }
  if (s === ' ' || s === '\r' || s === '\n') { if (state === 'playing') toTitle(); else startGame(mode); return; }
  const m = s.match(ARROW_RE);
  if (m) {
    if (state === 'title') {
      if (m[2] === 'C') cycleDice(1);
      else if (m[2] === 'D') cycleDice(-1);
      return;
    }
    const mod = m[1];
    input(ARROWS[m[2]], mod === '2' || mod === '6' || mod === '10');
    return;
  }
  for (const ch of s) {
    const low = ch.toLowerCase();
    if (state === 'title' && (low === 'a' || low === 'd')) {
      cycleDice(low === 'd' ? 1 : -1);
      continue;
    }
    if (state === 'title' && (low === 'w' || low === 's')) continue;
    if (low === 'w') input('N', ch === 'W');
    else if (low === 's') input('S', ch === 'S');
    else if (low === 'a') input('W', ch === 'A');
    else if (low === 'd') input('E', ch === 'D');
    else if (ch === '1') { if (state !== 'playing') startGame('endless'); }
    else if (ch === '2') { if (state !== 'playing') startGame('time'); }
    else if (low === 'q') quit(0);
  }
});

// --- screens ------------------------------------------------------------------
function renderTitle() {
  return [
    '',
    '  ' + bold('Dice Puzzle Ascii') + dim('  — a game in your terminal'),
    '  ' + dim('Roll dice and make the same numbers disappear'),
    '',
    '  [1] PLAY — ENDLESS',
    '  [2] PLAY — TIMED',
    '  ' + dim('Dice: ') + '◀ ' + bold(diceLabel) + ' ▶   ' + dim('← → or A D to change'),
    '',
    '  ' + dim('You are Kawamura, the small blue creature with horns'),
    '  ' + dim('The dots on a die show the number of that face'),
    '  ' + dim('Die colors: white=normal yellow=wood blue=ice gray=stone red=iron'),
    '  ' + dim('Dot colors: blue=1 brown=2 purple=3 red=4 gray=5 green=6'),
    '',
    '  ' + dim('Arrow keys or WASD  move'),
    '  ' + dim('Shift + arrow  climb on or off a die'),
    '  ' + dim('Space or Enter  title / start again    Esc  title    Q  quit'),
  ];
}

// The camera keeps the window of the board where it is while KAWAMURA walks
// around inside it.  It only scrolls when he reaches the edge of the window,
// and then by the smallest amount that keeps him visible.
const camera = makeCamera();
function resetCamera() {
  camera.x = null;
  camera.y = null;
}

function renderBoard() {
  const g = game;
  const cv = makeCanvas(g, {
    // A die that is about to appear blinks in gold.  Every face has its own
    // pair of shades, so the left side stays brighter than the right one.
    spawnColor: (face, on) => {
      const pair = SPAWN_COLORS[face] || SPAWN_COLORS.top;
      return on ? pair[0] : pair[1];
    },
    spawnPip: 94,
    // A die that is about to vanish blinks in green.  Every face has its
    // own pair of shades, so the left side stays brighter than the right one.
    matchColor: (face, on) => {
      const pair = MATCH_COLORS[face] || MATCH_COLORS.top;
      return on ? pair[0] : pair[1];
    },
    oneColor: (face, on) => {
      const pair = ONE_COLORS[face] || ONE_COLORS.top;
      return on ? pair[0] : pair[1];
    },
    groundColor,
    faceColor,
    pipColor,
    backdrop: BACKDROP,
    aquiColor: (part) => (useColor ? KAWAMURA_COLOR[part] || {} : KAWAMURA_MONO[part] || {}),
  });
  const p = g.players[0];

  // The board does not fit on a terminal, so only the window around the
  // player is shown; it scrolls when the player reaches its edge.
  const termW = process.stdout.columns || 80;
  const termH = process.stdout.rows || 24;
  // The rows the board does not use: the header, the ticker line, the help
  // line and the trailing newline.  Everything else is the playing field.
  const chrome = 4;
  // The window follows KAWAMURA, but only when he reaches its edge: while he
  // walks around inside the window the view stays completely still.
  const { winX, winY, winW, winH } = viewportFor(cv, p, termW, termH, chrome, camera);

  const lines = [];
  for (let r = 0; r < winH; r++) {
    let out = '';
    let curFg = null, curBg = null;
    for (let c = 0; c < winW; c++) {
      const cell = cellStyle(cv, winY + r, winX + c);
      if (cell.fg !== curFg || cell.bg !== curBg) {
        if (useColor) {
          if (curFg !== null || curBg !== null) out += '\x1b[0m';
          if (cell.fg !== null) out += `\x1b[38;5;${cell.fg}m`;
          if (cell.bg !== null) out += `\x1b[48;5;${cell.bg}m`;
        }
        curFg = cell.fg; curBg = cell.bg;
      }
      out += cell.ch;
    }
    if (useColor && (curFg !== null || curBg !== null)) out += '\x1b[0m';
    lines.push(out.replace(/\s+$/, ''));
  }

  // arrows telling that the board continues outside of the window
  const arrow = (winX > 0 ? '◀' : ' ') + (winX + winW < cv.w ? '▶' : ' ')
              + (winY > 0 ? '▲' : ' ') + (winY + winH < cv.h ? '▼' : ' ');

  const timeStr = g.maxTime ? `   ${Math.max(0, Math.ceil(g.maxTime - g.time))}s left` : '';
  const out = [];
  out.push(bold(mode === 'time' ? 'TIMED' : 'ENDLESS')
    + `   SCORE ${yellow(g.score)}   Lv.${g.level}   CLEARED ${g.cleared}${timeStr}`
    + '   ' + dim(arrow));
  out.push(...lines);
  // One single line for the events: the newest one stands on the left, the
  // older ones follow and are pushed out when the line overflows.
  const ticker = tickerText(termW - 2);
  out.push(ticker ? '  ' + dim(ticker) : '');
  out.push('  ' + dim('Arrow keys / WASD  move   Shift+arrow  climb on or off a die   Space  title   Q  quit'));
  return out;
}

function renderGameOver() {
  const r = game?.gameOver?.reason || '';
  return [
    '',
    '  ' + bold(red('GAME OVER')),
    '  ' + (REASON[r] || r),
    '  SCORE  ' + yellow(game?.score ?? 0),
    '',
    '  ' + dim('Space or Enter  PLAY AGAIN     1 / 2  choose a game     Q  quit'),
  ];
}

function render() {
  const lines =
    state === 'title' ? renderTitle()
    : state === 'playing' ? renderBoard()
    : renderGameOver();
  // Writing a full screen plus a trailing newline scrolls the terminal up by
  // one line: the top row disappears and the whole view jumps back and
  // forth.  So the content is capped to one line less than the terminal and
  // the newline is only written when there is room for it.
  const rows = process.stdout.rows || 24;
  const max = Math.max(1, rows - 1);
  if (lines.length > max) lines.length = max;
  const body = lines.join('\n') + (lines.length < max ? '\n' : '');
  // synchronized output: the terminal shows the new frame in one go, so the
  // clear + redraw does not flicker
  process.stdout.write('\x1b[?2026h\x1b[2J\x1b[H' + body + '\x1b[?2026l');
}

enterFullscreen();
render();
if (process.env.DICE_AUTO) startGame(process.env.DICE_AUTO);

const autoExit = Number(process.env.DICE_EXIT_AFTER || 0);
const startAt = Date.now();
let last = startAt;
setInterval(() => {
  const now = Date.now();
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  if (state === 'playing' && game) { game.update(dt); processEvents(); }
  render();
  if (autoExit && (now - startAt) / 1000 >= autoExit) quit(0);
}, 33);
