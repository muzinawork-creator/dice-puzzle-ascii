// core.js — pure XI [sai] game simulation (no DOM, no three.js)
// Unit-testable in Node. The renderer consumes this via events + state.

export const DIRS = { N: [0, -1], S: [0, 1], E: [1, 0], W: [-1, 0] };
export const DIR_LIST = ['N', 'S', 'E', 'W'];
export const OPPOSITE = { N: 'S', S: 'N', E: 'W', W: 'E' };

export const DICE_TYPE = {
  NORMAL: 'normal',
  WOOD: 'wood',
  ICE: 'ice',
  STONE: 'stone',
  IRON: 'iron',
};

// Durations (seconds) shared between core + renderer.
export const TIMING = {
  walk: 0.16,
  climb: 0.16,
  roll: 0.24,
  push: 0.18,
  iceStep: 0.13,
  iceMin: 0.2,
  sink: 10,
  niceSink: 10,
  niceSinkDelay: 1.2,
  spawn: 2.2,
  spawnWarn: 1.2,
};

export const SCORE_CAP = 999999;
export const GAME_OVER_FULL_SECONDS = 3.0;
export const GAME_OVER_STUCK_SECONDS = 1.0;
export const SPAWN_PAUSE_FILL = 0.85;

export function cellKey(x, y) { return x + ',' + y; }
export function parseKey(k) { const [x, y] = k.split(',').map(Number); return [x, y]; }

export function mulberry32(a) {
  return function () {
    let t = (a += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// --- Die orientation (明治サイコロキャラメル / spec 4.1) ---
// Coordinate convention: +Y = top, -Z = north(back), +Z = south(front, toward camera),
// +X = east(right), -X = west(left).
export function newDieState() {
  return { top: 1, bottom: 6, north: 5, south: 2, east: 3, west: 4 };
}

// Unified roll law (spec 4.1 v1.0.2): rolling toward D, the new top is the face
// opposite D; the face on D's side becomes the old top; the face opposite D's side
// becomes the old bottom; the two faces on the perpendicular axis stay.
export function rollState(state, dir) {
  const s = { ...state };
  switch (dir) {
    case 'N':
      s.top = state.south; s.south = state.bottom; s.bottom = state.north; s.north = state.top;
      break;
    case 'S':
      s.top = state.north; s.north = state.bottom; s.bottom = state.south; s.south = state.top;
      break;
    case 'E':
      s.top = state.west; s.west = state.bottom; s.bottom = state.east; s.east = state.top;
      break;
    case 'W':
      s.top = state.east; s.east = state.bottom; s.bottom = state.west; s.west = state.top;
      break;
  }
  return s;
}

// Enumerate all 24 valid orientations reachable from the base state.
export function allOrientations() {
  const key = (s) => [s.top, s.bottom, s.north, s.south, s.east, s.west].join(',');
  const set = new Map();
  const q = [newDieState()];
  set.set(key(q[0]), q[0]);
  while (q.length) {
    const cur = q.shift();
    for (const d of DIR_LIST) {
      const ns = rollState(cur, d);
      const k = key(ns);
      if (!set.has(k)) { set.set(k, ns); q.push(ns); }
    }
  }
  return [...set.values()];
}
export const ORIENTATIONS = allOrientations();

export function randomDieState(rng) {
  return { ...ORIENTATIONS[Math.floor(rng() * ORIENTATIONS.length)] };
}

export function makePlayer(id, x, y) {
  return { id, x, y, onDie: false, dieKey: null, dir: 'S' };
}

export class Game {
  constructor(opts = {}) {
    this.size = opts.size ?? 7;
    this.rng = opts.rng ?? mulberry32(opts.seed ?? ((Math.random() * 1e9) | 0));
    this.grid = new Map();
    this.dieSeq = 1;
    const cx = opts.playerX ?? Math.floor(this.size / 2);
    const cy = opts.playerY ?? Math.floor(this.size / 2);
    this.players = [makePlayer(0, cx, cy)];
    this.score = 0;
    this.level = 1;
    this.cleared = 0;
    this.clearsToLevel = 10;
    this.baseSpawnInterval = opts.spawnInterval ?? 3.0;
    this.maxTime = opts.maxTime ?? null;
    this.spawnTimer = opts.initialSpawnDelay ?? 1.0;
    this.action = null;
    this.queue = [];
    this.events = [];
    this.state = 'playing';
    this.gameOver = null;
    this.fullTimer = 0;
    this.stuckTimer = 0;
    this.pendingChain = 0;
    this.pendingResolve = false;
    this.pushedDieIds = new Set();
    this.rolledFromOneIds = new Set();
    this.time = 0;
    this.diceClearedTotal = 0;
    // The type picker has to exist before the initial dice are placed.
    if (opts.diceFn) this.diceFn = opts.diceFn;
    if (opts.initialDice) this.placeInitial(opts.initialDice);
    if (opts.startOnDie !== false) {
      const k = cellKey(this.players[0].x, this.players[0].y);
      if (!this.grid.has(k)) {
        const die = this.makeDie(this.players[0].x, this.players[0].y, false);
        this.grid.set(k, die);
      }
      const p = this.players[0];
      p.onDie = true;
      p.dieKey = cellKey(p.x, p.y);
    }
  }

  inBounds(x, y) { return x >= 0 && y >= 0 && x < this.size && y < this.size; }

  emit(e) { this.events.push(e); }

  pushInput(dir, shift = false) {
    if (!DIR_LIST.includes(dir)) return;
    if (this.queue.length < 4) this.queue.push({ dir, shift });
  }

  spawnIntervalFor(level) {
    return Math.max(2.2, (5.8 - (level - 1) * 0.44) * 2);
  }

  placeInitial(count) {
    const cx = this.players[0].x, cy = this.players[0].y;
    const cells = [];
    for (let y = 0; y < this.size; y++) for (let x = 0; x < this.size; x++) {
      if (x === cx && y === cy) continue;
      cells.push([x, y]);
    }
    // shuffle
    for (let i = cells.length - 1; i > 0; i--) {
      const j = Math.floor(this.rng() * (i + 1));
      [cells[i], cells[j]] = [cells[j], cells[i]];
    }
    for (let i = 0; i < Math.min(count, cells.length); i++) {
      const [x, y] = cells[i];
      const die = this.makeDie(x, y, false);
      this.grid.set(cellKey(x, y), die);
    }
  }

  makeDie(x, y, spawning) {
    const type = this.diceFn ? this.diceFn(this) : DICE_TYPE.NORMAL;
    const die = {
      id: this.dieSeq++, x, y,
      state: randomDieState(this.rng),
      type,
      sinking: false, sinkRemaining: 0, sinkDelay: 0,
      spawning, warnRemaining: spawning ? TIMING.spawnWarn : 0,
      spawnRemaining: spawning ? TIMING.spawn : 0,
    };
    return die;
  }

  // cells occupied after the in-flight action commits. During an action the
  // moving dice still occupy their current cells until commit, and their
  // destinations will be taken at commit — the spawner must avoid both so it
  // never overwrites a die or pre-empts a landing cell.
  futureOccupied() {
    const occ = new Set(this.grid.keys());
    if (!this.action) return occ;
    const p = this.players[0];
    const [dx, dy] = DIRS[this.action.dir];
    switch (this.action.type) {
      case 'roll': {
        const die = this.grid.get(p.dieKey);
        if (die) occ.add(cellKey(die.x + dx, die.y + dy));
        break;
      }
      case 'walk':
      case 'climb': {
        occ.add(cellKey(p.x + dx, p.y + dy));
        break;
      }
      case 'push': {
        const contactX = p.x + dx, contactY = p.y + dy;
        const line = this.collectLine(contactX, contactY, this.action.dir);
        if (line && line.length) {
          const last = line[line.length - 1];
          occ.add(cellKey(last.x + dx, last.y + dy));
        }
        break;
      }
      case 'ice': {
        occ.add(cellKey(this.action.toX, this.action.toY));
        break;
      }
    }
    return occ;
  }

  spawnDie() {
    if (this.state !== 'playing') return null;
    const occupied = this.futureOccupied();
    for (const p of this.players) occupied.add(cellKey(p.x, p.y));
    const avail = [];
    for (let y = 0; y < this.size; y++) for (let x = 0; x < this.size; x++) {
      const k = cellKey(x, y);
      if (!occupied.has(k)) avail.push([x, y]);
    }
    if (!avail.length) return null;
    const fill = 1 - avail.length / (this.size * this.size);
    if (fill > SPAWN_PAUSE_FILL) return null;
    const [x, y] = avail[Math.floor(this.rng() * avail.length)];
    const die = this.makeDie(x, y, true);
    this.grid.set(cellKey(x, y), die);
    this.emit({ type: 'spawn', dieId: die.id, key: cellKey(x, y), x, y, state: { ...die.state }, dieType: die.type, duration: TIMING.spawnWarn + TIMING.spawn });
    return die;
  }

  tryMove(dir, shift = false) {
    if (this.state !== 'playing' || this.action) return false;
    const p = this.players[0];
    const [dx, dy] = DIRS[dir];
    const tx = p.x + dx, ty = p.y + dy;
    if (!this.inBounds(tx, ty)) return false;
    const tkey = cellKey(tx, ty);
    const tdie = this.grid.get(tkey);
    if (shift) {
      // Shift: climb onto the die ahead, or climb down from the current die.
      if (tdie) {
        if (tdie.warnRemaining > 0) return false;
        this.action = { type: 'climb', dir, dieId: tdie.id, key: tkey, remaining: TIMING.climb, duration: TIMING.climb };
        this.emit({ type: 'climb', playerId: 0, dieId: tdie.id, fromX: p.x, fromY: p.y, toX: tx, toY: ty, dir, duration: TIMING.climb });
        p.dir = dir;
        return true;
      }
      if (p.onDie) {
        const die = this.grid.get(p.dieKey);
        if (die && !die.sinking && !die.spawning) {
          this.action = { type: 'walk', dir, dismount: true, remaining: TIMING.walk, duration: TIMING.walk };
          this.emit({ type: 'walk', playerId: 0, dismount: true, fromX: p.x, fromY: p.y, toX: tx, toY: ty, dir, duration: TIMING.walk });
          p.dir = dir;
          return true;
        }
      }
      return false;
    }
    if (p.onDie) {
      const die = this.grid.get(p.dieKey);
      if (!die) return false;
      if (die.sinking || die.spawning) {
        // A sinking/spawning die must not move. The player may step off to empty
        // ground, or climb onto an adjacent die.
        if (tdie) {
          if (tdie.warnRemaining > 0) return false;
          this.action = { type: 'climb', dir, dieId: tdie.id, key: tkey, remaining: TIMING.climb, duration: TIMING.climb };
          this.emit({ type: 'climb', playerId: 0, dieId: tdie.id, fromX: p.x, fromY: p.y, toX: tx, toY: ty, dir, duration: TIMING.climb });
          p.dir = dir;
          return true;
        }
        this.action = { type: 'walk', dir, dismount: true, remaining: TIMING.walk, duration: TIMING.walk };
        this.emit({ type: 'walk', playerId: 0, dismount: true, fromX: p.x, fromY: p.y, toX: tx, toY: ty, dir, duration: TIMING.walk });
        p.dir = dir;
        return true;
      }
      if (tdie) {
        if (tdie.warnRemaining > 0) return false;
        this.action = { type: 'climb', dir, dieId: tdie.id, key: tkey, remaining: TIMING.climb, duration: TIMING.climb };
        this.emit({ type: 'climb', playerId: 0, dieId: tdie.id, fromX: p.x, fromY: p.y, toX: tx, toY: ty, dir, duration: TIMING.climb });
        p.dir = dir;
        return true;
      }
      const ns = rollState(die.state, dir);
      die.sinking = false; die.sinkRemaining = 0; die.sinkDelay = 0;
      this.action = { type: 'roll', dir, dieId: die.id, remaining: TIMING.roll, duration: TIMING.roll };
      this.emit({
        type: 'roll', playerId: 0, dieId: die.id,
        fromX: p.x, fromY: p.y, toX: tx, toY: ty, dir,
        state: { ...die.state }, nextState: ns, duration: TIMING.roll,
      });
      p.dir = dir;
      return true;
    }
    // on ground
    if (!tdie) {
      this.action = { type: 'walk', dir, remaining: TIMING.walk, duration: TIMING.walk };
      this.emit({ type: 'walk', playerId: 0, fromX: p.x, fromY: p.y, toX: tx, toY: ty, dir, duration: TIMING.walk });
      p.dir = dir;
      return true;
    }
    if (tdie.sinking || tdie.spawning) {
      if (tdie.warnRemaining > 0) return false;
      this.action = { type: 'climb', dir, dieId: tdie.id, key: tkey, remaining: TIMING.climb, duration: TIMING.climb };
      this.emit({ type: 'climb', playerId: 0, dieId: tdie.id, fromX: p.x, fromY: p.y, toX: tx, toY: ty, dir, duration: TIMING.climb });
      p.dir = dir;
      return true;
    }
    // push
    const line = this.collectLine(tx, ty, dir);
    if (!line) return false;
    if (line.some(d => d.type === DICE_TYPE.STONE || d.type === DICE_TYPE.IRON)) return false;
    const contact = line[0];
    if (contact.type === DICE_TYPE.ICE) {
      let sx = tx, sy = ty;
      for (;;) {
        const nx = sx + dx, ny = sy + dy;
        if (!this.inBounds(nx, ny)) break;
        if (this.grid.has(cellKey(nx, ny))) break;
        if (this.players.some(q => !q.onDie && q.x === nx && q.y === ny)) break;
        sx = nx; sy = ny;
      }
      const dist = Math.max(Math.abs(sx - tx), Math.abs(sy - ty));
      const duration = Math.max(TIMING.iceMin, dist * TIMING.iceStep);
      this.action = { type: 'ice', dir, dieId: contact.id, key: tkey, toX: sx, toY: sy, playerToX: tx, playerToY: ty, remaining: duration, duration };
      this.emit({
        type: 'ice', playerId: 0, dieId: contact.id,
        fromX: tx, fromY: ty, toX: sx, toY: sy, dir,
        playerFromX: p.x, playerFromY: p.y, playerToX: tx, playerToY: ty, duration,
      });
      p.dir = dir;
      return true;
    }
    // ice deeper in a pushed column: treat as blocked (simplified rule)
    if (line.some(d => d.type === DICE_TYPE.ICE)) return false;
    const items = line.map(d => ({
      dieId: d.id, fromX: d.x, fromY: d.y, toX: d.x + dx, toY: d.y + dy,
      rollDir: d.type === DICE_TYPE.WOOD ? dir : null,
    }));
    this.action = { type: 'push', dir, remaining: TIMING.push, duration: TIMING.push };
    this.emit({
      type: 'push', playerId: 0, items, dir,
      playerFromX: p.x, playerFromY: p.y, playerToX: tx, playerToY: ty, duration: TIMING.push,
    });
    p.dir = dir;
    return true;
  }

  collectLine(x, y, dir) {
    const [dx, dy] = DIRS[dir];
    const line = [];
    let cx = x, cy = y;
    while (this.inBounds(cx, cy) && this.grid.has(cellKey(cx, cy))) {
      const d = this.grid.get(cellKey(cx, cy));
      if (d.sinking || d.spawning) return null;
      line.push(d);
      cx += dx; cy += dy;
    }
    if (!this.inBounds(cx, cy) || this.grid.has(cellKey(cx, cy))) return null;
    return line;
  }

  movePlayer(p, nx, ny) { p.x = nx; p.y = ny; }

  commitAction(a) {
    const p = this.players[0];
    switch (a.type) {
      case 'walk': {
        const [dx, dy] = DIRS[a.dir];
        this.movePlayer(p, p.x + dx, p.y + dy);
        if (a.dismount) { p.onDie = false; p.dieKey = null; }
        break;
      }
      case 'climb': {
        const [dx, dy] = DIRS[a.dir];
        const nx = p.x + dx, ny = p.y + dy;
        const k = cellKey(nx, ny);
        const die = this.grid.get(k);
        this.movePlayer(p, nx, ny);
        if (die) { p.onDie = true; p.dieKey = k; }
        else { p.onDie = false; p.dieKey = null; }
        break;
      }
      case 'roll': {
        const die = this.grid.get(p.dieKey);
        if (!die) { p.onDie = false; p.dieKey = null; break; }
        const [dx, dy] = DIRS[a.dir];
        const nx = die.x + dx, ny = die.y + dy;
        const oldK = cellKey(die.x, die.y);
        this.grid.delete(oldK);
        die.x = nx; die.y = ny;
        if (die.state.top === 1) this.rolledFromOneIds.add(die.id);
        die.state = rollState(die.state, a.dir);
        die.sinking = false; die.sinkRemaining = 0; die.sinkDelay = 0;
        const nk = cellKey(nx, ny);
        this.grid.set(nk, die);
        this.movePlayer(p, nx, ny);
        p.dieKey = nk;
        this.pushedDieIds.add(die.id);
        break;
      }
      case 'push': {
        const [dx, dy] = DIRS[a.dir];
        const contactX = p.x + dx, contactY = p.y + dy;
        const line = this.collectLine(contactX, contactY, a.dir);
        if (line) {
          for (let i = line.length - 1; i >= 0; i--) {
            const d = line[i];
            const oldK = cellKey(d.x, d.y);
            this.grid.delete(oldK);
            d.x += dx; d.y += dy;
            if (d.type === DICE_TYPE.WOOD) d.state = rollState(d.state, a.dir);
            this.grid.set(cellKey(d.x, d.y), d);
            this.pushedDieIds.add(d.id);
          }
        }
        this.movePlayer(p, contactX, contactY);
        break;
      }
      case 'ice': {
        const die = this.grid.get(a.key);
        if (die) {
          const oldK = cellKey(die.x, die.y);
          this.grid.delete(oldK);
          die.x = a.toX; die.y = a.toY;
          this.grid.set(cellKey(a.toX, a.toY), die);
        }
        this.movePlayer(p, a.playerToX, a.playerToY);
        break;
      }
    }
  }

  // --- Vanish / Chain / Nice-One resolution (spec 3.1 / 3.2 / 3.3) ---
  components() {
    const parent = new Map();
    for (const k of this.grid.keys()) parent.set(k, k);
    const find = (k) => {
      while (parent.get(k) !== k) { parent.set(k, parent.get(parent.get(k))); k = parent.get(k); }
      return k;
    };
    for (const [k, die] of this.grid) {
      if (die.spawning) continue;
      const [x, y] = parseKey(k);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nk = cellKey(x + dx, y + dy);
        const nd = this.grid.get(nk);
        if (nd && !nd.spawning && nd.state.top === die.state.top) parent.set(find(k), find(nk));
      }
    }
    const comps = new Map();
    for (const [k, die] of this.grid) {
      if (die.spawning) continue;
      const r = find(k);
      if (!comps.has(r)) comps.set(r, { face: die.state.top, dice: [] });
      comps.get(r).dice.push(die);
    }
    return [...comps.values()];
  }

  addScore(points) { this.score = Math.min(SCORE_CAP, this.score + points); }

  resolveField() {
    if (this.state !== 'playing') return;
    const hasExistingSinking = [...this.grid.values()].some(d => d.sinking);
    let chainNum = hasExistingSinking ? this.pendingChain + 1 : 1;
    const comps = this.components();
    const marked = new Set();
    let didSink = false;
    let maxChain = chainNum - 1;

    for (let guard = 0; guard < 40; guard++) {
      let found = false;
      for (const comp of comps) {
        const f = comp.face;
        if (f === 1) continue;
        const size = comp.dice.length;
        const keys = comp.dice.map(d => cellKey(d.x, d.y));
        if (keys.every(k => marked.has(k))) continue;
        const hasSinking = comp.dice.some(d => d.sinking || marked.has(d.id));
        let act = null;
        if (chainNum === 1 && !hasSinking && size >= f) act = 'vanish';
        else if (hasSinking && size >= 2 && comp.dice.some(d => !d.sinking)) act = 'chain';
        if (act) {
          const hasNew = comp.dice.some(d => !d.sinking);
          for (const d of comp.dice) {
            if (!d.sinking) d.sinking = true;
            if (hasNew) d.sinkRemaining = TIMING.sink;
            marked.add(cellKey(d.x, d.y));
          }
          const points = f * size * chainNum;
          this.addScore(points);
          didSink = true;
          maxChain = chainNum;
          this.emit({ type: act, face: f, links: size, chainNum, points, keys, dieIds: comp.dice.map(d => d.id), grace: hasNew });
          found = true;
        }
      }
      if (!found) break;
      chainNum++;
    }

    // Nice-One: a "1" adjacent to a die that sank THIS call clears ALL 1s,
    // including the one the player just rolled in on.
    // Uses `marked` (this resolve's sinks) so leftover-sinking dice don't re-trigger it every resolve.
    // A "1" that was just pushed (slid) or rolled adjacent to an already-sinking die also triggers it —
    // but only when that sinking neighbor is NOT a 1 (a sinking 1 does not trigger).
    let niceTrigger = false;
    for (const [k, die] of this.grid) {
      if (die.state.top === 1 || this.rolledFromOneIds.has(die.id)) {
        const [x, y] = parseKey(k);
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nk = cellKey(x + dx, y + dy);
          if (marked.has(nk)) { niceTrigger = true; break; }
          if (this.pushedDieIds.has(die.id)) {
            const nd = this.grid.get(nk);
            if (nd && nd.sinking && nd.state.top !== 1) { niceTrigger = true; break; }
          }
        }
      }
      if (niceTrigger) break;
    }
    this.pushedDieIds.clear();
    this.rolledFromOneIds.clear();
    if (niceTrigger) {
      const ones = [];
      for (const [k, die] of this.grid) {
        if (die.state.top === 1) ones.push([k, die]);
      }
      const fresh = ones.filter(([, d]) => !d.sinking);
      if (ones.length && fresh.length) {
        for (const [k, die] of ones) {
          if (!die.sinking) { die.sinking = true; die.sinkRemaining = TIMING.niceSink; die.sinkDelay = TIMING.niceSinkDelay; }
          marked.add(k);
        }
        const hc = Math.max(1, chainNum);
        const points = 1 * ones.length * hc;
        this.addScore(points);
        maxChain = Math.max(maxChain, hc);
        didSink = true;
        this.emit({ type: 'nice', links: ones.length, chainNum: hc, points, keys: ones.map(([k]) => k), dieIds: ones.map(([, d]) => d.id), grace: false });
      }
    }

    this.pendingChain = didSink ? Math.max(1, maxChain) : 0;
  }

  canMoveAny(p) {
    for (const dir of DIR_LIST) {
      const [dx, dy] = DIRS[dir];
      const tx = p.x + dx, ty = p.y + dy;
      if (!this.inBounds(tx, ty)) continue;
      const tdie = this.grid.get(cellKey(tx, ty));
      if (p.onDie) {
        const die = this.grid.get(p.dieKey);
        if (!die) continue;
        if (die.sinking || die.spawning) {
          if (!tdie) return true;
          if (tdie.warnRemaining <= 0) return true;
          continue;
        }
        if (!tdie) return true;
        if (tdie.warnRemaining <= 0) return true;
        continue;
      } else {
        if (!tdie) return true;
        if (tdie.sinking || tdie.spawning) return true;
        const line = this.collectLine(tx, ty, dir);
        if (line && !line.some(d => d.type === DICE_TYPE.STONE || d.type === DICE_TYPE.IRON)) {
          const contact = line[0];
          if (contact.type === DICE_TYPE.ICE) return true;
          if (line.some(d => d.type === DICE_TYPE.ICE)) continue;
          return true;
        }
      }
    }
    return false;
  }

  doGameOver(reason) {
    if (this.state !== 'playing') return;
    this.state = 'gameover';
    this.gameOver = { reason, score: this.score };
    this.emit({ type: 'gameover', reason, score: this.score });
  }

  checkGameOver(dt) {
    const p = this.players[0];
    let empty = 0;
    for (let y = 0; y < this.size; y++) for (let x = 0; x < this.size; x++) {
      if (!this.grid.has(cellKey(x, y))) empty++;
    }
    const hasSinking = [...this.grid.values()].some(d => d.sinking);
    if (empty === 0 && !hasSinking) this.fullTimer += dt;
    else this.fullTimer = 0;
    if (this.fullTimer >= GAME_OVER_FULL_SECONDS) { this.doGameOver('full'); return; }

    if (this.action) { this.stuckTimer = 0; return; }
    const onDie = p.onDie ? this.grid.get(p.dieKey) : null;
    if (onDie && (onDie.sinking || onDie.spawning)) { this.stuckTimer = 0; return; }
    if (!this.canMoveAny(p)) {
      this.stuckTimer += dt;
      if (this.stuckTimer >= GAME_OVER_STUCK_SECONDS) { this.doGameOver('stuck'); }
    } else this.stuckTimer = 0;
  }

  update(dt) {
    if (this.state !== 'playing') return;
    this.time += dt;
    if (this.maxTime && this.time >= this.maxTime) { this.doGameOver('time'); return; }

    if (!this.action) {
      while (this.queue.length && !this.action) {
        const { dir, shift } = this.queue.shift();
        if (this.tryMove(dir, shift)) break;
      }
      if (this.pendingResolve && !this.action) { this.pendingResolve = false; this.resolveField(); }
    }
    if (this.action) {
      this.action.remaining -= dt;
      if (this.action.remaining <= 0) {
        const a = this.action;
        this.action = null;
        this.commitAction(a);
        this.resolveField();
      }
    }

    // spawner
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      this.spawnDie();
      const interval = this.spawnIntervalFor(this.level);
      this.spawnTimer = interval * (0.85 + this.rng() * 0.3);
    }

    // spawning dice progress
    for (const [k, die] of this.grid) {
      if (die.spawning) {
        if (die.warnRemaining > 0) {
          die.warnRemaining -= dt;
        } else {
          die.spawnRemaining -= dt;
          if (die.spawnRemaining <= 0) {
            die.spawning = false;
            this.pendingResolve = true;
            this.emit({ type: 'spawn-done', key: k, dieId: die.id });
          }
        }
      }
    }

    // sinking dice progress + removal
    const toRemove = [];
    for (const [k, die] of this.grid) {
      if (die.sinking) {
        if (die.sinkDelay > 0) { die.sinkDelay -= dt; }
        else {
          die.sinkRemaining -= dt;
          if (die.sinkRemaining <= 0.0001) toRemove.push([k, die]);
        }
      }
    }
    for (const [k, die] of toRemove) {
      this.grid.delete(k);
      this.cleared++;
      this.diceClearedTotal++;
      let wasStanding = false;
      for (const pl of this.players) {
        if (pl.onDie && pl.dieKey === k) { pl.onDie = false; pl.dieKey = null; wasStanding = true; }
      }
      this.emit({ type: 'removed', key: k, dieId: die.id, wasStanding });
    }

    // level up
    while (this.cleared >= this.clearsToLevel) {
      this.cleared -= this.clearsToLevel;
      this.level++;
      this.clearsToLevel = 10 + (this.level - 1) * 2;
      this.emit({ type: 'levelup', level: this.level });
    }

    this.checkGameOver(dt);
  }
}
